package dytt.dao;

import java.io.IOException;
import java.sql.*;
import java.util.ListIterator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class DyttDao {
	ListIterator<Element> tr=null;
	ListIterator<Element> nr=null;
	ListIterator<Element> dr=null;
	Connection conn=null;
	int size=0;
	int i=1;
	String url="https://www.dytt8.net/";
	public Document getDocument() {
		try {
			return Jsoup.connect(url).timeout(5000).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public void insert() {

		String driver="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost/dytt";
		String user="root";
		String pass="root";
		Document doc=getDocument();
		Elements etype=doc.select("[class=title_all]").select("strong");
		Elements ename=doc.select("tbody").select("td").select("a:contains(��)");
		Elements edate=doc.select("font");
		Elements eurl=doc.select("tbody").select("td").select("a[href]:contains(��)");
		size=etype.size();

		try {
			Class.forName(driver);
		    conn=DriverManager.getConnection(url, user, pass);
			if(!conn.isClosed()) { 
				System.out.println("���ݿ�������");
			}
			String sql="insert into ds (id,type,name,url,uploadTime) values (?,?,?,?,?)";
			PreparedStatement pst=conn.prepareStatement(sql);
			String str="2019-06-28";
		    tr=etype.listIterator();
		    nr=ename.listIterator();
		    dr=edate.listIterator();
			while(tr.hasNext()) {
				Element typetemp=tr.next();
				String type=typetemp.text();
			System.out.println(type);
			pst.setString(2, type);
		    while(nr.hasNext()) {
		    	pst.setInt(1, i);
				i++;
				Element temp=nr.next();
				Element dt=dr.next();
		    	String date=dt.text();
		    	pst.setString(5, date);
		    	String name=temp.text();
		    	name=name.substring(name.indexOf("��"), name.indexOf("��"));
		    	String link=temp.attr( "href");
		    	pst.setString(4, link);
		    	pst.setString(3,name);
		        pst.executeUpdate();
		    }
		    	
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public void query(){
		try {
		Statement st=conn.createStatement();
		String sql="select * from ds";
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			int id=rs.getInt("id");
			String name=rs.getString("name");
			String type=rs.getString("type");
			String link=rs.getString("url");
			String  d=rs.getString("uploadTime");
			System.out.println(id+"  "+type+"  "+name+"��"+"  "+ link+"  "+d);
		}
	}catch(SQLException e) {
		e.printStackTrace();
	}
}
public static void main(String[] args) {
	DyttDao dytt=new DyttDao();
	dytt.insert();
	dytt.query();
}
}
