package com.osdemo.philospher;

public class Test {
public static void main(String[] args) {
	for(int i =0;i<5;i++){
		new Philospher("��ѧ��"+i).start();
	}
}
}
