package com.osdemo.process;

/**
 * @author XJK
 *Description������ʱ�����תʱ���ǳ��ȣ�������׼ȷ˵��ʱ��
 */
public class Process {
private char name;
private double arrivelTime; 
private double serverTime;
private double startTime;
private double finishTime;  
private double turnTime;
private double powerTurnTime;
private double stillNeedTime;
public Process(char name,double arriveltime,double servertime) {
	this.name=name;
	this.arrivelTime=arriveltime;
	this.serverTime=servertime;
}
public char getName() {
	return name;
}
public void setName(char name) {
	this.name = name;
}
public double getArrivelTime() {
	return arrivelTime;
}
public void setArrivelTime(double arrivelTime) {
	this.arrivelTime = arrivelTime;
}
public double getServerTime() {
	return serverTime;
}
public void setServerTime(double serverTime) {
	this.serverTime = serverTime;
}
public double getStartTime() {
	return startTime;
}
public void setStartTime(double startTime) {
	this.startTime = startTime;
}
public double getFinishTime() {
	return finishTime;
}
public void setFinishTime(double finishTime) {
	this.finishTime = finishTime;
}
public double getTurnTime() {
	return turnTime;
}
public void setTurnTime(double turnTime) {
	this.turnTime = turnTime;
}
public double getPowerTurnTime() {
	return powerTurnTime;
}
public void setPowerTurnTime(double powerTurnTime) {
	this.powerTurnTime = powerTurnTime;
}
public double getStillNeedTime() {
	return stillNeedTime;
}
public void setStillNeedTime(double stillNeedTime) {
	this.stillNeedTime = stillNeedTime;
}
}
